import HomePage from "./home/page";

export default function Index() {
  return <HomePage />;
}
