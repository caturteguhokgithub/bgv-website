"use client";

import LayoutWeb from "@/components/layouts/page";
import SectionBanner from "./banner";

export default function FreelanceAgencyPage() {
  return (
    <LayoutWeb>
      <SectionBanner />
    </LayoutWeb>
  );
}
