"use client";

import LayoutWeb from "@/components/layouts/page";
import SectionCard from "./card";

export default function AboutDetailPage() {
  return (
    <LayoutWeb>
      <SectionCard />
    </LayoutWeb>
  );
}
